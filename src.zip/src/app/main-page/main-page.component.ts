import { Component, OnInit } from '@angular/core';
import { CartService } from '../cart.service';

interface MenuItem {
  id: number;
  name: string;
  price: number;
  image: string;
  quantity: number;
}

@Component({
  selector: 'app-main-page',
  templateUrl: './main-page.component.html',
  styleUrls: ['./main-page.component.css']
})
export class MainPageComponent implements OnInit {
  menuItems: MenuItem[] = [];

  constructor(private cartService: CartService) {}

  ngOnInit() {
    this.menuItems = [
      { id: 1, name: 'Pizza', price: 10.99, image: 'pizza.jpg', quantity: 0 },
      { id: 2, name: 'Burger', price: 8.99, image: 'burger.jpg', quantity: 0 },
      { id: 3, name: 'Coffee', price: 5.99, image: 'coffee.jpg', quantity: 0 },
      { id: 4, name: 'Cookie', price: 2.99, image: 'cookie.jpg', quantity: 0 },
      { id: 5, name: 'Milkshake', price: 6.99, image: 'milkshake.jpg', quantity: 0 },
      { id: 6, name: 'Nuggets', price: 8.99, image: 'nuggets.jpg', quantity: 0 },
      { id: 7, name: 'Pepsi', price: 2.00, image: 'pepsi.jpg', quantity: 0 },
      { id: 8, name: 'Mountain Dew', price: 2.00, image: 'mountain-dew.jpg', quantity: 0 },






      
    ];
  }

  addToCart(item: MenuItem): void {
    
    item.quantity++;

    this.cartService.addToCart(item);
  }
}
