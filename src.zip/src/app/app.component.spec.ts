import { TestBed, ComponentFixture } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppComponent } from './app.component';
import { CartService } from './cart.service';

describe('AppComponent', () => {
  let fixture: ComponentFixture<AppComponent>;
  let component: AppComponent;
  let cartService: CartService;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      declarations: [AppComponent],
      providers: [CartService],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AppComponent);
    component = fixture.componentInstance;
    cartService = TestBed.inject(CartService);
    fixture.detectChanges();
  });

  it('should create the app', () => {
    expect(component).toBeTruthy();
  });

  it('should add an item to the cart', () => {
    const item = { id: 1, name: 'Test Item', price: 20, image: 'test.jpg', quantity: 1 };
    cartService.addToCart(item);
    expect(cartService.cartItems[0]).toEqual(item);
  });

  it('should clear the cart', () => {
    cartService.clearCart();
    expect(cartService.cartItems.length).toBe(0);
  });

});
