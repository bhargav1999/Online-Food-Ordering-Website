import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class MenuService {
  private menuItems = [
    { id: 1, name: 'Pizza', price: 15, image: 'pizza.jpg' },
    { id: 2, name: 'Burger', price: 10, image: 'burger.jpg' },
    { id: 3, name: 'Coffee', price: 5, image: 'coffee.jpg' },
    { id: 4, name: 'Milkshake', price: 8, image: 'milkshake.jpg' },
    { id: 5, name: 'Cookie', price: 2, image: 'cookie.jpg' },
    { id: 6, name: 'Pepsi', price: 2.5, image: 'pepsi.jpg' },
    { id: 7, name: 'Mountain Dew', price: 2.5, image: 'mountain-dew.jpg' },
    { id: 8, name: 'Nuggets', price: 12, image: 'nuggets.jpg' },
  ];

  getMenuItems() {
    return this.menuItems;
  }
}
