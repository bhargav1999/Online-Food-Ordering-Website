import { CartService } from './cart.service';

describe('CartService', () => {
  let service: CartService;

  beforeEach(() => {
    service = new CartService();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should add item to cart', () => {
    const item = { id: 1, name: 'Test Item', price: 20, image: 'test.jpg', quantity: 1 };
    service.addToCart(item);
    expect(service.cartItems[0]).toEqual(item);
  });

  it('should clear the cart', () => {
    service.clearCart();
    expect(service.cartItems.length).toBe(0);
  });

});
